# track.plot
#
# ploting n.curves curves in the same graphic

# coord matrix (big.n, nc), nc>=2
# big.labels matrix (big.n, 2)
# first.point, last.point logical

track.plot <- function(coord, big.labels, colors=NULL, line.types=NULL,
                       new.plot=T,
                       points=FALSE,
                       every.each=!points,#labels every each "each" points
                       each=5,
                       first.point=T,
                       last.point=T,
                       main="Track plot", 
                       bf.lines=NULL, 
                       smooth.Tukey=NULL, ...
                        ){
  require(RColorBrewer)
  
  labels <- unique(big.labels[,1])
  n.curves <- length(labels)
  if (is.null(colors)) colors <- rep(brewer.pal(n=min(n.curves,8),"Dark2"),ceiling(n.curves/8))
  if (is.null(line.types)) line.types <- rep(1,n.curves)
  if (new.plot) plot(coord[,1:2],type="n",main=main,...)
  for (i in setdiff(1:n.curves,bf.lines)){
    I.i <- which(big.labels[,1]==labels[i])
    n.i <- length(I.i)
    aux <- coord[I.i,2]
    if (!is.null(smooth.Tukey)) aux <- smooth(coord[I.i,2], kind=smooth.Tukey)
    if (points) points(coord[I.i,1], aux, pch=19,col=colors[i])
    lines(coord[I.i,1], aux,col=colors[i],lty=line.types[[i]])
    if (every.each){
      first.point<-F
      last.point<-T
      for (j in seq(1,n.i,by=each)) text(coord[I.i[j],1],aux[j],paste(big.labels[I.i[j],2],labels[i],sep="."), col=colors[i])
    }
    if (first.point) text(coord[I.i[1],1],aux[1],paste(big.labels[I.i[1],2],labels[i],sep="."), col=colors[i])
    if (last.point) text(coord[I.i[n.i],1],aux[n.i],paste(big.labels[I.i[n.i],2],labels[i],sep="."),col=colors[i])
  }
  
  if (!is.null(bf.lines)){
    for (i in bf.lines){
      I.i <- which(big.labels[,1]==labels[i])
      n.i <- length(I.i)
      aux <- coord[I.i,2]
      if (!is.null(smooth.Tukey)) aux <- smooth(coord[I.i,2], kind=smooth.Tukey)
      if (points) points(coord[I.i,1], aux, pch=19,col=colors[i])
      lines(coord[I.i,1], aux,col=colors[i],lw=3,lty=line.types[[i]])
      if (every.each){
        first.point<-F
        last.point<-T
        for (j in seq(1,n.i,by=each)) text(coord[I.i[j],1],aux[j],paste(big.labels[I.i[j],2],labels[i],sep="."), col=colors[i], font=2)
      }
      if (first.point) text(coord[I.i[1],1],aux[1],paste(big.labels[I.i[1],2],labels[i],sep="."), col=colors[i], font=2)
      if (last.point) text(coord[I.i[n.i],1],aux[n.i],paste(big.labels[I.i[n.i],2],labels[i],sep="."),col=colors[i], font=2)
    }
  }
}

