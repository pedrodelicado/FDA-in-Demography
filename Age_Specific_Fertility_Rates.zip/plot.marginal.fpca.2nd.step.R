# plot.marginal.fpca.2nd.step Graphics for the Second Step of 
#                             Marginal Functional Principal Component Analysis
#
# Input:
#   sfpcaout.1st.step, sfpcaout.2nd.step Two lists obtained from sfpca function, with the following elements:
#                 w   nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#
#  j.th.ppal.funct.st.step What ppal. funct. in the 1st step is analyzed in the second step 
#                         (with results in sfpcaout.2nd.step). Default: 1
#
# Require: RColorBrewer
#          track.plot (track.plot.R)
plot.marginal.fpca.2nd.step <- function(sfpcaout.1st.step, sfpcaout.2nd.step, 
                                        j.th.ppal.funct.st.step=1,
                                        label.1=NULL,
                                        label.2=seq(1,length(sfpcaout.2nd.step$lambda)),
                                        main.title="marg.FPCA 1st and 2nd steps",
                                        short.title="marg.FPCA",
                                        big.labels=NULL,
                                        arg.s = seq(1,length(sfpcaout.1st.step$V)),
                                        arg.t = seq(1,length(sfpcaout.2nd.step$V)),
                                        name.s = "s", name.t = "t", 
                                        nc=4, nc.2=nc,
                                        s.before.t =FALSE, 
                                        colors=NULL,
                                        each=15,
                                        ...){
  
  lambda <- sfpcaout.1st.step$lambda
  pctvar <- sfpcaout.1st.step$pctvar
  V <- sfpcaout.1st.step$V
  Y <- sfpcaout.1st.step$Y
  mu <- sfpcaout.1st.step$mu
  I <- sfpcaout.1st.step$I
  X <- t(sfpcaout.1st.step$X) # original data (re-arranged)
  n <- length(lambda)
  T <- dim(V)[1]
  
  lambda.2 <- sfpcaout.2nd.step$lambda
  pctvar.2 <- sfpcaout.2nd.step$pctvar
  V.2 <- sfpcaout.2nd.step$V
  Y.2 <- sfpcaout.2nd.step$Y
  mu.2 <- sfpcaout.2nd.step$mu
  I.2 <- sfpcaout.2nd.step$I
  n.2 <- length(lambda.2)
  T.2 <- dim(V.2)[1]
  
  if (is.null(label.1)){
    label.1 <-  outer(label.2,arg.t,paste,sep=".")
  }
  
  n.s <- length(arg.s)
  n.t <- length(arg.t)
  
  par(mfrow=c(4,4))
  
  # G.1: bi-dimensional mean function
  #   mu.2.args Mean function of the observed data
  big.X <- matrix(0,nrow=n.2,ncol=n.t*n.s)
  for (i in 1:n.2){
    big.X[i,] <- array(t(X[((i-1)*n.t+1):(i*n.t),]))
    #this way write data corresponding to a given value of arg.t jointly
  }
  mu.2.args <- apply(big.X,2,mean)
    #
  if (s.before.t){
    image(arg.s,arg.t,t(matrix(mu.2.args,nrow=n.t,ncol=length(arg.s),byrow=T)), 
          main="Mean function",xlab=name.s,ylab=name.t)
  }else{
    image(arg.t,arg.s,matrix(mu.2.args,nrow=n.t,ncol=length(arg.s),byrow=T), 
          main="Mean function",xlab=name.t,ylab=name.s)  
  }
  
  # G.2: eigenvalues 1st.step
  plot(pctvar[1:min(n.s,n.t*n.2)],type='l',xlab="PC",ylab="% of variance")
  text(seq(1,nc),pctvar[1:nc],as.character(round(pctvar[1:nc],digits=2)),pos=4)
  title("% of var. explained for each PC at 1st step")
  
  
  # 
  if (is.null(colors)){
    require(RColorBrewer)
    colors <- rep(brewer.pal(n=min(n.2,8),"Dark2"),ceiling(n.2/8))
  }
  ## G.3: 1st FPC in the second round: scores in the Plane of the 1st and 2nd FPC of the 1st Step
  # 2nd vs 1st principal coordinates. 1st Step
  if (is.null(big.labels)){
    big.labels <- matrix(unlist(strsplit(label.1,split=".",fixed=TRUE)),ncol=2,byrow=T)[,c(2,1)]
  }  
  track.plot(coord=sfpcaout.1st.step$Y, big.labels=big.labels,last.point=F,each=each,
             xlab=paste('1st principal function (',round(sfpcaout.1st.step$pctvar[1],digits=2),'%)',sep=""),
             ylab=paste('2nd principal function (',round(sfpcaout.1st.step$pctvar[2],digits=2),'%)',sep=""),
             main=paste(main.title,". Marginal FPCA, First Step",sep=""),colors=colors)
  
  
  # G.4: mean +/- ppal.funct.j-th 1st.step 
  j.1st <- j.th.ppal.funct.st.step
  cte <- 1/3
  alpha <- cte * diff(range(Y[,j.1st]))/2
  ylim <- c(min(sfpcaout.1st.step$mu-alpha*sfpcaout.1st.step$V[,j.1st]),max(sfpcaout.1st.step$mu+alpha*sfpcaout.1st.step$V[,j.1st]))
  plot(I,mu- V[,j.1st]*alpha, type='l',lwd=2, col=4, 
       main=paste("mean +/- Ppal.Funct. ",j.1st,sep=""),  
       ylim=ylim,xlab=name.s,ylab=short.title)
  lines(I,mu,lwd=2,col=1)
  lines(I,mu + V[,j.1st]*alpha,lwd=2,col=2)
  
  
  # G.5: eigenvalues 2nd.step
  plot(pctvar.2,type='l',xlab="PC",ylab="% of variance")
  text(seq(1,nc.2),pctvar.2[1:nc.2],as.character(round(pctvar.2[1:nc.2],digits=2)),pos=4)
  title("% of var. explained for each PC at 2nd step")
  
  # G.6: 2nd vs 1st principal coordinates. 2nd Step
  plot(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2], pch='.',
       xlab=paste('1st principal function (',round(sfpcaout.2nd.step$pctvar[1],digits=2),'%)',sep=""),
       ylab=paste('2nd principal function (',round(sfpcaout.2nd.step$pctvar[2],digits=2),'%)',sep=""),
       main=paste('Second Step. (from FPC ',j.1st,' in the First Step)',sep=""))
  text(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2],label.2,col=colors)
  
  # G.7, G.8: mean.ppal.funct.j-th.1st.step +/- 1st & 2nd ppal.funct. 2nd.step 
  col4 = rainbow(4,start=.075,end=.75,v=.75,s=.95)[c(4,1,2,3)] # substitutes of "black", "red", "green" and "blue"
  
  cte <- 1/2
  alpha <- cte * c(diff(range(Y.2[,1])), diff(range(Y.2[,2])))/2
  ylim.2 <- c(min(mu.2-alpha*V.2[,1]),max(mu.2+alpha*V.2[,1]))
  for (j in 1:2){
    plot(I.2,mu.2 - V.2[,j]*alpha[j] ,type='l',col=col4[4], lwd=2, 
         main=paste("mean +/- PC ",j," Second Step (",round(pctvar.2[j],dig=2),"% of var.)",sep=""),
         xlab=name.t,ylab=paste("Score at First Step PC ",j.1st,sep=""),
         ylim=ylim.2)
    lines(I.2,mu.2 ,col=col4[1],lwd=2)
    lines(I.2,mu.2 + V.2[,j]*alpha[j] ,col=col4[2],lwd=2)
  }
  
  # G.9: 
  fpc.1 <- matrix(Y[,1],nrow=n.2,ncol=n.t,byrow=TRUE)
  fpc.2 <- matrix(Y[,2],nrow=n.2,ncol=n.t,byrow=TRUE)
  mu1 <- apply(fpc.1,2,mean)
  mu2 <- apply(fpc.2,2,mean)

  track.plot(coord=sfpcaout.1st.step$Y, big.labels=big.labels,last.point=F,every.each=F,
             xlab='1st principal function (First Step)', 
             ylab='2nd principal function (First Step)',
             main="Interpreating 1st FPC in the Second Step ",
             colors=rep(8,n.2))
  
  cte <- 1/2
  alpha <- cte * c(diff(range(Y.2[,1])), diff(range(Y.2[,2])))/2
  
  lines(mu1 - (j.1st==1)*V.2[,1]*alpha[1], mu2 - (j.1st==2)*V.2[,1]*alpha[1], col=col4[4],lwd=2)
#  points(mu1 - (j.1st==1)*V.2[,1]*alpha[1], mu2 - (j.1st==2)*V.2[,1]*alpha[1], col=,pch=19)
  
  lines(mu1,mu2,lwd=2,col=col4[1])
#  points(mu1,mu2,pch=19)
  text(mu1[1],mu2[1],y.lab[1])
  
  lines(mu1 + (j.1st==1)*V.2[,1]*alpha[1], mu2 + (j.1st==2)*V.2[,1]*alpha[1], col=col4[2],lwd=2)
  #  points(mu1 + (j.1st==1)*V.2[,1]*alpha[1], mu2 + (j.1st==2)*V.2[,1]*alpha[1], col=col4[2],pch=19)
  
  #G.10, G.11, G.12:
  #1st FPC in the second round: Dynamic graphic of mean(t) +/- Cte*scores(t)*(1st and 2nd ppal.funct of the 1st Step)
  cte.1 <- 2
  alpha.1 <- cte.1 * c(diff(range(sfpcaout.1st.step$Y[,1])), diff(range(sfpcaout.1st.step$Y[,2])))/2
#  alpha.1 <- cte.1*c(1,1)
  
  for (j in c(1,ceiling(n.t/2),n.t)){
    t.j <- arg.t[j]
    plot(I,mu,type='l',lwd=2, col=1, main=paste("mean +/- Ppal.Funct. 1 (Second Step), t=",t.j,sep=""),  
         ylim=ylim,xlab=name.s,ylab=short.title)
    
    lines(I, mu + 
            (mu1 - (j.1st==1)*V.2[,1]*alpha[1])[j]*V[,1]*alpha.1[1] +
            (mu2 - (j.1st==2)*V.2[,1]*alpha[1])[j]*V[,2]*alpha.1[2], 
          col=col4[4],lwd=2)
    
    lines(I, mu + mu1[j]*V[,1]*alpha.1[1] + mu2[j]*V[,2]*alpha.1[2] ,col=col4[1],lwd=2)
    
    lines(I, mu + 
            (mu1 + (j.1st==1)*V.2[,1]*alpha[1])[j]*V[,1]*alpha.1[1] +
            (mu2 + (j.1st==2)*V.2[,1]*alpha[1])[j]*V[,2]*alpha.1[2], 
          col=col4[2],lwd=2)
  }
  
  # G.13
  ## 2nd FPC in the second round: scores in the Plane of the 1st and 2nd FPC of the 1st Step
  track.plot(coord=sfpcaout.1st.step$Y, big.labels=big.labels,last.point=F,every.each=F,
             xlab='1st principal function (First Step)', 
             ylab='2nd principal function (First Step)',
             main="Interpreating 2nd FPC  in the Second Step ",
             colors=rep(8,n.2))
  
  lines(mu1 - (j.1st==1)*V.2[,2]*alpha[2], mu2 - (j.1st==2)*V.2[,2]*alpha[2], col=col4[4],lwd=2)
  #  points(mu1 - (j.1st==1)*V.2[,2]*alpha[2], mu2 - (j.1st==2)*V.2[,2]*alpha[2], col=col4[4],pch=19)
  
  lines(mu1,mu2,lwd=2,col=col4[1])
  #  points(mu1,mu2,pch=19)
  text(mu1[1],mu2[1],y.lab[1])
  
  lines(mu1 + (j.1st==1)*V.2[,2]*alpha[2], mu2 + (j.1st==2)*V.2[,2]*alpha[2], col=col4[2],lwd=2)
  #  points(mu1 + (j.1st==1)*V.2[,2]*alpha[2], mu2 + (j.1st==2)*V.2[,2]*alpha[2], col=col4[2],pch=19)
  
  # G.14, G.15, G.16
  ## 2nd FPC in the second round: Dynamic graphic of mean(t) +/- Cte*scores(t)*(1st and 2nd ppal.funct of the 1st Step)
  cte.1 <- 2
  alpha.1 <- cte.1 * c(diff(range(sfpcaout.1st.step$Y[,1])), diff(range(sfpcaout.1st.step$Y[,2])))/2
#  alpha.1 <- cte.1*c(1,1)
  
  for (j in c(1,ceiling(n.t/2),n.t)){
    t.j <- arg.t[j]
    plot(I,mu,type='l',lwd=2, col=1, main=paste("mean +/- Ppal.Funct. 2 (Second Step), t=",t.j,sep=""),  
         ylim=ylim,xlab=name.s,ylab=short.title)
    
    lines(I, mu + 
            (mu1 - (j.1st==1)*V.2[,2]*alpha[2])[j]*V[,1]*alpha.1[1] +
            (mu2 - (j.1st==2)*V.2[,2]*alpha[2])[j]*V[,2]*alpha.1[2], 
          col=col4[4],lwd=2)
    
    lines(I, mu + mu1[j]*V[,1]*alpha.1[1] + mu2[j]*V[,2]*alpha.1[2] ,col=col4[1],lwd=2)
    
    lines(I, mu + 
            (mu1 + (j.1st==1)*V.2[,2]*alpha[2])[j]*V[,1]*alpha.1[1] +
            (mu2 + (j.1st==2)*V.2[,2]*alpha[2])[j]*V[,2]*alpha.1[2], 
          col=col4[2],lwd=2)
    
  }
}




# plot.marginal.fpca.2nd.step.3by3 Graphics for the Second Step of 
#                             Marginal Functional Principal Component Analysis
#
# Input:
#   sfpcaout.1st.step, sfpcaout.2nd.step Two lists obtained from sfpca function, with the following elements:
#                 w   nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#
#  j.th.ppal.funct.st.step What ppal. funct. in the 1st step is analyzed in the second step 
#                         (with results in sfpcaout.2nd.step). Default: 1
#
# Require: RColorBrewer
#          track.plot (track.plot.R)
plot.marginal.fpca.2nd.step.3by3 <- function(sfpcaout.1st.step, sfpcaout.2nd.step, 
                                        j.th.ppal.funct.st.step=1,
                                        label.1=NULL,
                                        label.2=seq(1,length(sfpcaout.2nd.step$lambda)),
                                        main.title="marg.FPCA 1st and 2nd steps",
                                        short.title="marg.FPCA",
                                        big.labels=NULL,
                                        arg.s = seq(1,length(sfpcaout.1st.step$V)),
                                        arg.t = seq(1,length(sfpcaout.2nd.step$V)),
                                        name.s = "s", name.t = "t", 
                                        nc=4, nc.2=nc,
                                        s.before.t =FALSE, 
                                        colors=NULL,
                                        each=15,
                                        ...){
  
  lambda <- sfpcaout.1st.step$lambda
  pctvar <- sfpcaout.1st.step$pctvar
  V <- sfpcaout.1st.step$V
  Y <- sfpcaout.1st.step$Y
  mu <- sfpcaout.1st.step$mu
  I <- sfpcaout.1st.step$I
  X <- t(sfpcaout.1st.step$X) # original data (re-arranged)
  n <- length(lambda)
  T <- dim(V)[1]
  
  lambda.2 <- sfpcaout.2nd.step$lambda
  pctvar.2 <- sfpcaout.2nd.step$pctvar
  V.2 <- sfpcaout.2nd.step$V
  Y.2 <- sfpcaout.2nd.step$Y
  mu.2 <- sfpcaout.2nd.step$mu
  I.2 <- sfpcaout.2nd.step$I
  n.2 <- length(lambda.2)
  T.2 <- dim(V.2)[1]
  
  if (is.null(label.1)){
    label.1 <-  outer(label.2,arg.t,paste,sep=".")
  }
  
  n.s <- length(arg.s)
  n.t <- length(arg.t)
  
  par(mfrow=c(3,3))
  
  
  
  j.1st <- j.th.ppal.funct.st.step
  
  cte <- 1/2
  alpha <- cte * c(diff(range(Y.2[,1])), diff(range(Y.2[,2])))/2
  ylim.2 <- c(min(mu.2-alpha*V.2[,1]),max(mu.2+alpha*V.2[,1]))
  

  cte.1 <- 1/4
  alpha.1 <- cte.1 * diff(range(Y[,1]))/2
  ylim.1 <- c(min(mu-alpha.1*V[,1]), max(mu+alpha.1*V[,1]))
  
  cte.1 <- (2/3)*c(1,1.4,1.8)/(ylim.2[2]-ylim.2[1])
  alpha.1 <- cte.1[j.1st] * diff(range(Y[,j.1st]))/2
  
  
  # G.1: 2nd vs 1st principal coordinates. 2nd Step
  plot(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2], pch='.',
       xlab=paste('1st ppal. funct. (',round(sfpcaout.2nd.step$pctvar[1],digits=2),'%)',sep=""),
       ylab=paste('2nd ppal. funct. (',round(sfpcaout.2nd.step$pctvar[2],digits=2),'%)',sep=""),
       main=paste('2nd Step from ppal. funct. ',j.1st,' in the 1st Step',sep=""))
  text(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2],label.2,col=1)
  
  # G.2, G.3: mean.ppal.funct.j-th.1st.step +/- 1st & 2nd ppal.funct. 2nd.step 
  col4 = rainbow(4,start=.075,end=.75,v=.75,s=.95)[c(4,1,2,3)] # substitutes of "black", "red", "green" and "blue"
  
  for (j in 1:2){
    plot(I.2,mu.2 - V.2[,j]*alpha[j] ,type='l',col=col4[4], lwd=2, 
         main=paste("2nd Step: mean +/- ppal.funct. ",j," (",round(pctvar.2[j],dig=2),"%)",sep=""),
         xlab=name.t,ylab=paste("Score at ppal. funct. ",j.1st," in the 1st Step",sep=""),
         ylim=ylim.2)
    lines(I.2,mu.2 ,col=col4[1],lwd=2)
    lines(I.2,mu.2 + V.2[,j]*alpha[j] ,col=col4[2],lwd=2)
  }
  
  fpc.1 <- matrix(Y[,1],nrow=n.2,ncol=n.t,byrow=TRUE)
  fpc.2 <- matrix(Y[,2],nrow=n.2,ncol=n.t,byrow=TRUE)
  fpc.3 <- matrix(Y[,3],nrow=n.2,ncol=n.t,byrow=TRUE)
  mu1 <- apply(fpc.1,2,mean)
  mu2 <- apply(fpc.2,2,mean)
  mu3 <- apply(fpc.3,2,mean)
  mu.fpc<- cbind(mu1,mu2,mu3)
  
  
  #G.4, G.5, G.6:
  #1st FPC in the 2nd round: Dynamic graphic of mean(t) +/- Cte*scores(t)*(1st and 2nd ppal.funct of the 1st Step)
  
  for (j in c(1,ceiling(n.t/2),n.t)){
    t.j <- arg.t[j]
    plot(I,mu,type='l',lwd=2, col=1, 
#         main=paste("mean +/- Ppal.Funct. 1 (2nd Step), ",name.t,"=",t.j,sep=""),  
         main=paste("Ppal. Funct. 1 in 2nd Step, ",name.t,"=",t.j,sep=""),  
         ylim=ylim.1,xlab=name.s,ylab=short.title)
    abline(h=0,col=8,lwd=2)      
    
    lines(I, mu + (mu.fpc[,j.1st]-V.2[,1]*alpha[1])[j]*V[,j.1st]*alpha.1, col=col4[4],lwd=2)
    
    lines(I, mu + mu.fpc[j,j.1st]                     *V[,j.1st]*alpha.1, col=col4[1],lwd=2)
    
    lines(I, mu + (mu.fpc[,j.1st]+V.2[,1]*alpha[1])[j]*V[,j.1st]*alpha.1, col=col4[2],lwd=2)
  }
  

  # G.7, G.8, G.9
  ## 2nd FPC in the 2nd round: Dynamic graphic of mean(t) +/- Cte*scores(t)*(1st and 2nd ppal.funct of the 1st Step)
  
  for (j in c(1,ceiling(n.t/2),n.t)){
    t.j <- arg.t[j]
    plot(I,mu,type='l',lwd=2, col=1, 
#         main=paste("mean +/- Ppal.Funct. 2 (2nd Step), ",name.t,"=",t.j,sep=""),  
         main=paste("Ppal. Funct. 2 in 2nd Step, ",name.t,"=",t.j,sep=""),  
         ylim=ylim.1,xlab=name.s,ylab=short.title)
    abline(h=0,col=8,lwd=2)      
    
    lines(I, mu + (mu.fpc[,j.1st]-V.2[,2]*alpha[2])[j]*V[,j.1st]*alpha.1, col=col4[4],lwd=2)
    
    lines(I, mu + mu.fpc[j,j.1st]                     *V[,j.1st]*alpha.1, col=col4[1],lwd=2)
    
    lines(I, mu + (mu.fpc[,j.1st]+V.2[,2]*alpha[2])[j]*V[,j.1st]*alpha.1, col=col4[2],lwd=2)        
  }
}


# plot.marginal.fpca.2nd.step.1by3 Graphics for the Second Step of 
#                             Marginal Functional Principal Component Analysis
#
# Input:
#   sfpcaout.1st.step, sfpcaout.2nd.step Two lists obtained from sfpca function, with the following elements:
#                 w   nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#
#  j.th.ppal.funct.st.step What ppal. funct. in the 1st step is analyzed in the second step 
#                         (with results in sfpcaout.2nd.step). Default: 1
#
# Require: RColorBrewer
#          track.plot (track.plot.R)
plot.marginal.fpca.2nd.step.1by3 <- function(sfpcaout.1st.step, sfpcaout.2nd.step, 
                                             j.th.ppal.funct.st.step=1,
                                             label.1=NULL,
                                             label.2=seq(1,length(sfpcaout.2nd.step$lambda)),
                                             main.title="marg.FPCA 1st and 2nd steps",
                                             short.title="marg.FPCA",
                                             big.labels=NULL,
                                             arg.s = seq(1,length(sfpcaout.1st.step$V)),
                                             arg.t = seq(1,length(sfpcaout.2nd.step$V)),
                                             name.s = "s", name.t = "t", 
                                             nc=4, nc.2=nc,
                                             s.before.t =FALSE, 
                                             colors=NULL,
                                             each=15,
                                             new.graphic=FALSE,
                                             ...){
  
  lambda <- sfpcaout.1st.step$lambda
  pctvar <- sfpcaout.1st.step$pctvar
  V <- sfpcaout.1st.step$V
  Y <- sfpcaout.1st.step$Y
  mu <- sfpcaout.1st.step$mu
  I <- sfpcaout.1st.step$I
  X <- t(sfpcaout.1st.step$X) # original data (re-arranged)
  n <- length(lambda)
  T <- dim(V)[1]
  
  lambda.2 <- sfpcaout.2nd.step$lambda
  pctvar.2 <- sfpcaout.2nd.step$pctvar
  V.2 <- sfpcaout.2nd.step$V
  Y.2 <- sfpcaout.2nd.step$Y
  mu.2 <- sfpcaout.2nd.step$mu
  I.2 <- sfpcaout.2nd.step$I
  n.2 <- length(lambda.2)
  T.2 <- dim(V.2)[1]
  
  if (is.null(label.1)){
    label.1 <-  outer(label.2,arg.t,paste,sep=".")
  }
  
  n.s <- length(arg.s)
  n.t <- length(arg.t)
  
  if (new.graphic) par(mfrow=c(3,3))
  
  j.1st <- j.th.ppal.funct.st.step
  
  cte <- 1/2
  alpha <- cte * c(diff(range(Y.2[,1])), diff(range(Y.2[,2])))/2
  ylim.2 <- c(min(mu.2-alpha*V.2[,1]),max(mu.2+alpha*V.2[,1]))
  
  
  cte.1 <- 1/4
  alpha.1 <- cte.1 * diff(range(Y[,1]))/2
  ylim.1 <- c(min(mu-alpha.1*V[,1]), max(mu+alpha.1*V[,1]))
  
  cte.1 <- (2/3)*c(1,1.4,1.8)/(ylim.2[2]-ylim.2[1])
  alpha.1 <- cte.1[j.1st] * diff(range(Y[,j.1st]))/2
  
  
  # G.1: 2nd vs 1st principal coordinates. 2nd Step
  plot(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2], pch='.',
       xlab=paste('1st ppal. funct. (',round(sfpcaout.2nd.step$pctvar[1],digits=2),'%)',sep=""),
       ylab=paste('2nd ppal. funct. (',round(sfpcaout.2nd.step$pctvar[2],digits=2),'%)',sep=""),
       main=paste('2nd Step from ppal. funct. ',j.1st,' in the 1st Step',sep=""))
  text(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2],label.2,col=1)
  
  # G.2, G.3: mean.ppal.funct.j-th.1st.step +/- 1st & 2nd ppal.funct. 2nd.step 
  col4 = rainbow(4,start=.075,end=.75,v=.75,s=.95)[c(4,1,2,3)] # substitutes of "black", "red", "green" and "blue"
  
  for (j in 1:2){
    plot(I.2,mu.2 - V.2[,j]*alpha[j] ,type='l',col=col4[4], lwd=2, 
         main=paste("2nd Step: mean +/- ppal.funct. ",j," (",round(pctvar.2[j],dig=2),"%)",sep=""),
         xlab=name.t,ylab=paste("Score at ppal. funct. ",j.1st," in the 1st Step",sep=""),
         ylim=ylim.2)
    lines(I.2,mu.2 ,col=col4[1],lwd=2)
    lines(I.2,mu.2 + V.2[,j]*alpha[j] ,col=col4[2],lwd=2)
  }
}

# plot.marginal.fpca.2nd.step.1by2 Graphics for the Second Step of 
#                             Marginal Functional Principal Component Analysis
#
# Input:
#   sfpcaout.1st.step, sfpcaout.2nd.step Two lists obtained from sfpca function, with the following elements:
#                 w   nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#
#  j.th.ppal.funct.st.step What ppal. funct. in the 1st step is analyzed in the second step 
#                         (with results in sfpcaout.2nd.step). Default: 1
#
# Require: RColorBrewer
#          track.plot (track.plot.R)
plot.marginal.fpca.2nd.step.1by2 <- function(sfpcaout.1st.step, sfpcaout.2nd.step, 
                                             j.th.ppal.funct.st.step=1,
                                             label.1=NULL,
                                             label.2=seq(1,length(sfpcaout.2nd.step$lambda)),
                                             main.title="marg.FPCA 1st and 2nd steps",
                                             short.title="marg.FPCA",
                                             big.labels=NULL,
                                             arg.s = seq(1,length(sfpcaout.1st.step$V)),
                                             arg.t = seq(1,length(sfpcaout.2nd.step$V)),
                                             name.s = "s", name.t = "t", 
                                             nc=4, nc.2=nc,
                                             s.before.t =FALSE, 
                                             colors=NULL,
                                             each=15,
                                             new.graphic=FALSE,
                                             ...){
  
  lambda <- sfpcaout.1st.step$lambda
  pctvar <- sfpcaout.1st.step$pctvar
  V <- sfpcaout.1st.step$V
  Y <- sfpcaout.1st.step$Y
  mu <- sfpcaout.1st.step$mu
  I <- sfpcaout.1st.step$I
  X <- t(sfpcaout.1st.step$X) # original data (re-arranged)
  n <- length(lambda)
  T <- dim(V)[1]
  
  lambda.2 <- sfpcaout.2nd.step$lambda
  pctvar.2 <- sfpcaout.2nd.step$pctvar
  V.2 <- sfpcaout.2nd.step$V
  Y.2 <- sfpcaout.2nd.step$Y
  mu.2 <- sfpcaout.2nd.step$mu
  I.2 <- sfpcaout.2nd.step$I
  n.2 <- length(lambda.2)
  T.2 <- dim(V.2)[1]
  
  if (is.null(label.1)){
    label.1 <-  outer(label.2,arg.t,paste,sep=".")
  }
  
  n.s <- length(arg.s)
  n.t <- length(arg.t)
  
  if (new.graphic) par(mfrow=c(3,2))
  
  j.1st <- j.th.ppal.funct.st.step
  
  
  
  # G.1: 2nd vs 1st principal coordinates. 2nd Step
  plot(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2], pch='.',
       xlab=paste('Eigenfunction 1 (FEV: ',round(sfpcaout.2nd.step$pctvar[1],digits=2),'%)',sep=""),
       ylab=paste('Eigenfunction 2 (FEV: ',round(sfpcaout.2nd.step$pctvar[2],digits=2),'%)',sep=""),
       main=paste('2nd Step from eigenfunction ',j.1st,' in the 1st Step',sep=""))
  text(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,2],label.2,col=1)
  
  # G.2: 3rd vs 1st principal coordinates. 2nd Step
  plot(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,3], pch='.',
       xlab=paste('Eigenfunction 1 (FEV: ',round(sfpcaout.2nd.step$pctvar[1],digits=2),'%)',sep=""),
       ylab=paste('Eigenfunction 3 (FEV: ',round(sfpcaout.2nd.step$pctvar[3],digits=2),'%)',sep=""),
       main=paste('2nd Step from eigenfunction ',j.1st,' in the 1st Step',sep=""))
       text(sfpcaout.2nd.step$Y[,1],sfpcaout.2nd.step$Y[,3],label.2,col=1)
}

