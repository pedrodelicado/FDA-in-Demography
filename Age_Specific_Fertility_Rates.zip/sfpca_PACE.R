# sfpca.FPCA  Functional Principal Component Analysis using PACE,
#             but with the same inputs and outputs than 
#             funcion 'sfpca'
#
# Giving a sample of n curves, the program computes eigenvectors/eigenfunctions of its 
# sampling covariance operator. The proposals of Kneip & Utikal (JASA, 2001) are used.
#
# Inputs:
#          X  A (T,n) matrix. Each column is a "sampling curve", represented as the 
#             collection of its values at T consecutives points: t_1,...,t_T.
#          I  (Optional) The set of index points: t_1,...,t_T.
#             Default: I=[1:T]';
#         nc  (Optional) Number of components to be registered.
#             Default: nc=4;
#
# Outputs:
#          w  nc principal components of Var(t(X)*X) defined from data curves X  
#     lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#             defined from data curves X  
#     pctvar  Percentage of variance explined by each component
#          V  (T,nc) matrix with the eigenfunctions of Sigma evaluated at I.
#          Y  (n,nc) matrix with the value of the first nc sampling functional 
#             principal Components.
#         mu  aritmetic mean of the n functions in X
#       recX  Reconstruction of matrix X from the nc principal functions
#          I  The set of index points: t_1,...,t_T.
#
#
# (C) Pedro Delicado, October 2015
#
sfpca <- function(X,I=seq(1,dim(X)[1]), nc=4, change.signs=rep(1,nc)){
  Xt <- t(X)
  n = dim(Xt)[1]
  nts = dim(Xt)[2]
  fpca.op = list(dataType = "Dense", 
                 methodSelectK =nc, #numComponents = nc, 
                 error=FALSE, 
                 useBinnedData="OFF", 
                 nRegGrid=nts)
  if (sum(is.na(X)) == 0){
    tList <- lapply(1:n, function(x) 1:nts)
    yList <- lapply(1:n, function(x) Xt[x,])
  } else {
    fpca.op$dataType = 'DenseWithMV'
    tList <- vector('list', length  = n)
    yList <- vector('list', length = n)
    tvec <- 1:nts
    for (i in 1:n){
      ind <- which(!is.na(Xt[i,]))
      yList[[i]] <- Xt[i,ind]
      tList[[i]] <- tvec[ind]
    }
  }
  
  out.res <- FPCA(yList, tList, fpca.op)

  xiVar <- out.res$xiVar
  cumFVE <- out.res$cumFVE

  # -----------------
  lambda <- out.res$lambda
  V <- out.res$phi
  Y <- out.res$xiEst
  mu <- out.res$mu 
  pctvar <- 100*c(cumFVE[1],diff(cumFVE))
  # -----------------
  signs <- diag( sign(apply(V,2,sum)) ) * change.signs
  #
  # Reconstructing X with nc principal components
  recX <- mu%*% array(1,dim=c(1,n)) + V%*%t(Y) 
  return(list(w=NULL,lambda=lambda,pctvar=pctvar,
              V=V%*%signs,Y=Y%*%signs,mu=mu,recX=recX,I=I,X=X,
              xiVar=xiVar,cumFVE=cumFVE))
}


# sfpca.Cov    Sampling Functional Principal Component Analysis from a Covariance operator
#
# Giving a Covarince matrix (values of a Covariance operator at TxT grid points), 
# the program computes eigenvectors/eigenfunctions of its sampling covariance operator. 
#
# Inputs:
#          C  A (T,T) covariance matrix, being the values of a covariance oerator Sigma
#             at T consecutives points: t_1,...,t_T.
#          I  (Optional) The set of index points: t_1,...,t_T.
#             Default: I=[1:T]';
#         nc  (Optional) Number of components to be registered.
#             Default: nc=2;
#
# Outputs:
#          w  nc principal components of C  
#     lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#     pctvar  Percentage of variance explined by each component
#       recC  Reconstruction of matrix C from the nc principal functions
#          I  The set of index points: t_1,...,t_T.
#
# Use:
#     [lambda,V,Y,mu,I]=SFPCA(X,I,c);
#
# (C) Pedro Delicado, Matlab: October 2001, R-version: April 2005
#
sfpca.Cov <- function(C,I=seq(1,dim(C)[1]),nc=4){
  T <- dim(C)[1]
  #
  # Computing of the eigensytem of C
  eigC <- eigen(C, symmetric=TRUE)
  lambda <- eigC$values
  w <- eigC$vectors[,1:nc]
  #
  # Reconstructing C with nc principal components
  recC <- w %*% t(w)
  return(list(w=w,lambda=lambda,pctvar=100*lambda/sum(lambda),recC=recC,I=I))
}

plot.sfpca.Cov <- function(sfpcaout, X=NULL,wt=NULL,label=NULL,
                           color=1,alpha.q=.25,equispaced=TRUE,ylimite=NULL,...){
  lambda <- sfpcaout$lambda
  pctvar <- sfpcaout$pctvar
  w <- sfpcaout$w
  I <- sfpcaout$I
  nc <- 4
  
  par(mfrow=c(3,2))
  # par(mfrow=c(4,2))
  
  # eigenvalues
  plot(pctvar,type='l',xlab="PC",ylab="% of variance")
  text(seq(1,nc)+.75,pctvar[1:nc],as.character(round(pctvar[1:nc],digits=2)))
  title("Percentage of variance explained for each PC")
  
  if (is.null(X)){
    plot(0,0)    
  }else{
    T <- dim(X)[1]
    n <- dim(X)[2]
    if (is.null(wt)) wt<-rep(1/n,n)
    if (is.null(label)) label<- 1:n
    #
    # Centering data
    if (any(wt < 0) || (s <- sum(wt)) == 0) 
      stop("weights must be non-negative and not all zero")
    wt <- wt/s
    center <- colSums(wt %*% t(X))
    mu <- array(center,dim=c(T,1))
    Xc <- X - mu %*% array(1,dim=c(1,n))
    # Computing scores
    V <- as.matrix(t(Xc)) %*% w
    # 2nd vs 1st principal coordinates
    plot(V[,1],V[,2], pch='.',xlab='1st principal function', ylab='2nd principal function')
    title(main= '2nd vs 1st principal coordinates')
    text(V[,1],V[,2],label, col=color)    
  }
  
  # principal functions
  for (j in seq(1,nc)){
    plot(I,w[,j], type='l', main=paste("PC ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""))  
    lines(I,0*I,col=2)
  }
}



# intgnum Integral num?rica por el m?todo del trapecio de f entre a y b
#
# Input:
#            f  (nx1) valores de la funci?n que se quiere integrar en los puntos de I.
#        xeval  (nx1) Puntos en los que se ha evaluado la funci?n. I(1)=a, I(n)=b.
#   equispaced  TRUE if evalpts are equispaced (used to do faster numerical integration). FALSE is the default. 
# Output:
#   Integ Valor de la integral.
#
# Use:
#     Integ <- intgnum(f,xeval)
#
# (C) Pedro Delicado, Octubre 2001
#
intgnum <- function(f,xeval,equispaced=FALSE){
  n <- length(f)
  if (equispaced){
    dx <- xeval[2]-xeval[1]
    Integ <- sum(f, na.rm=TRUE)*dx
  } else{
    Integ <- sum( .5*(f[2:n]+f[1:(n-1)])*diff(xeval), na.rm=TRUE )
  }
  Integ
}


# plot.sfpca.2.reduced Graphics for Sampling Functional Principal Component Analysis. Only 2 PC.
#
# This program provided a graphical output to SFPCA analysis. It is asumed that 
# program SFPC was runned.
#
# Input:
#   sfpcaout  A list obtained from sfpc function, with the following elements:
#                 w  nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#         nc  (Optional) Number of components to be ploted.
#             Default: nc=dim(sfpcaout$V)[2];
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#      color  (Optional) Color to be used to print the names of the n observed curves.
#             Default: all in black
#
plot.sfpca.2.reduced <- function(sfpcaout, label=seq(1,length(sfpcaout$lambda)),color=1,alpha.q=.25,equispaced=TRUE,ylimite=NULL,...){
  lambda <- sfpcaout$lambda
  pctvar <- sfpcaout$pctvar
  V <- sfpcaout$V
  Y <- sfpcaout$Y
  mu <- sfpcaout$mu
  I <- sfpcaout$I
  nc <- 2
  
  n <- length(lambda)
  T <- dim(V)[1]
  
  par(mfrow=c(3,2))
  # par(mfrow=c(4,2))
  
  # eigenvalues
  plot(pctvar[1:min(n,T)],type='l',xlab="PC",ylab="% of variance")
  text(seq(1,nc)+.75,pctvar[1:nc],as.character(round(pctvar[1:nc],digits=2)))
  title("Percentage of variance explained for each PC")
  
  # 2nd vs 1st principal coordinates
  plot(Y[,1],Y[,2], pch='.',xlab='1st principal function', ylab='2nd principal function')
  title(main= '2nd vs 1st principal coordinates')
  text(Y[,1],Y[,2],label, col=color)
  
  # principal curves
  for (j in seq(1,nc)){
    plot(I,V[,j], type='l', main=paste("PC ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""))  
    lines(I,0*I,col=2)
  }
  
  # mean +/- PC 
  cte <- 1
  alpha <- cte * (max(mu)-min(mu))/5
  for (j in seq(1,nc)){
    plot(I,mu,type='l',lwd=2, main=paste("mean +/- PC ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""),  
         ylim=c(min(mu)-alpha,max(mu)+alpha))
    lines(I,mu + V[,j]/max(abs(V[,j]))*alpha ,col=2)
    lines(I,mu - V[,j]/max(abs(V[,j]))*alpha ,col=4)
  }
}


# plot.sfpca.3pc Graphics for Sampling Functional Principal Component Analysis. Only 3 PC.
#
# This program provided a graphical output to SFPCA analysis. It is asumed that 
# program SFPC was runned.
#
# Input:
#   sfpcaout  A list obtained from sfpc function, with the following elements:
#                 w  nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#      color  (Optional) Color to be used to print the names of the n observed curves.
#             Default: all in black
#
# requires: track.plot
plot.sfpca.3pc <- function(sfpcaout, label=seq(1,length(sfpcaout$lambda)),color=1,
                           equispaced=TRUE, alpha.traditional=TRUE,...){
  lambda <- sfpcaout$lambda
  pctvar <- sfpcaout$pctvar
  V <- sfpcaout$V
  Y <- sfpcaout$Y
  mu <- sfpcaout$mu
  I <- sfpcaout$I
  
  nc <- 3
  
  n <- length(lambda)
  T <- dim(V)[1]
  
  par(mfrow=c(3,2))
  
  cte <- 1
  alpha <- cte * (max(mu)-min(mu))/5
  ylim <- c(min(mu)-alpha,max(mu)+alpha)
  
  #  cte.1 <- 1/3*c(.75,1,1.25)
  cte.1 <- 1/4*c(1,1,1)
  alpha.1 <- cte.1[1] * diff(range(Y[,1]))/2
  ylim.1 <- c(min(mu-alpha.1*V[,1]), max(mu+alpha.1*V[,1]))
  
  if (!alpha.traditional) ylim <- ylim.1
  
  for (j in seq(1,nc)){
    
    # principal curves
    plot(I,V[,j], type='n', main=paste("Eigenfunction ",j," (FVE: ",round(pctvar[j],dig=2),"%)",sep=""))  
    abline(h=0,col=8,lwd=2) 
    lines(I,V[,j],lwd=2)
    
    # mean +/- PC 
    plot(I,mu,type='n', main=paste("Mean +/- Eigenfunction ",j,sep=""), ylim=ylim)
    abline(h=0,col=8,lwd=2)      
    lines(I,mu,lwd=2)
    if (alpha.traditional){
      lines(I,mu + V[,j]/max(abs(V[,j]))*alpha ,col=2,lwd=2)
      lines(I,mu - V[,j]/max(abs(V[,j]))*alpha ,col=4,lwd=2)  
    }else{
      alpha.1 <- cte.1[j] * diff(range(Y[,j]))/2
      lines(I,mu + V[,j]*alpha.1 ,col=2,lwd=2)
      lines(I,mu - V[,j]*alpha.1 ,col=4,lwd=2)  
    }
  }
}

# plot.sfpca.4pc.ctrd Graphics for Sampling Functional Principal Component Analysis. 
#                     Only 4 PC. Functional data are assumed to be centered 
#                    (so no mean +/- ppal.fctn are drwan)
#
# This program provided a graphical output to SFPCA analysis. It is asumed that 
# program SFPC was runned.
#
# Input:
#   sfpcaout  A list obtained from sfpc function, with the following elements:
#                 w  nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#      color  (Optional) Color to be used to print the names of the n observed curves.
#             Default: all in black
#
plot.sfpca.4pc.ctrd <- function(sfpcaout,nc=4,xlab="I",ylab="Eigenfunction"){
  lambda <- sfpcaout$lambda
  pctvar <- sfpcaout$pctvar
  V <- sfpcaout$V
  Y <- sfpcaout$Y
  mu <- sfpcaout$mu
  I <- sfpcaout$I
  
  n <- length(lambda)
  T <- dim(V)[1]
  
  if (nc==4)
    par(mfrow=c(2,2))
  else
    par(mfrow=c(1,3))
  
  
  for (j in seq(1,nc)){
    
    # principal curves
    plot(I,V[,j], type='n', xlab=xlab, ylab=paste(ylab,j),
         #main=paste("Ppal. Funct. ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""))  
         main=paste("Eigenfunction ",j," (FVE: ",round(pctvar[j],dig=2),"%)",sep=""))  
    abline(h=0,col=8,lwd=2) 
    lines(I,V[,j],lwd=2)
    
  }
}



# sfpca.biv    Sampling Functional Principal Component Analysis for bivariate functional data
#
# Giving a sample of n curves, the program computes eigenvectors/eigenfunctions of its 
# sampling covariance operator. The proposals of Kneip & Utikal (JASA, 2001) are used.
#
# Inputs:
#          X  A (T1*T2,n) matrix. Each column is a "sampling curve", represented as the 
#             collection of its values at T1*T2 consecutives points: (t_1,...,t_T1, s1,...,s_T2).
#          I1  (Optional) The set of index points: t_1,...,t_T1.
#             Default: I1=[1:T1]';
#          I2  (Optional) The set of index points: s_1,...,s_T1.
#             Default: I2=[1:T2]';
#      T1, T2 Dimension of each bivariate functional data (required if I1 or I2 are not present)
#         nc  (Optional) Number of components to be registered.
#             Default: nc=2;
#         wt  length n array with the weigths of the n functions in X to be used to compute their mean
#
# Outputs:
#          w  nc principal components of Var(t(X)*X) defined from data curves X  
#     lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#             defined from data curves X  
#     pctvar  Percentage of variance explined by each component
#          V  (T,nc) matrix with the eigenfunctions of Sigma evaluated at I.
#          Y  (n,nc) matrix with the value of the first nc sampling functional 
#             principal Components.
#         mu  aritmetic mean of the n functions in X
#       recX  Reconstruction of matrix X from the nc principal functions
#          I  The set of index points: t_1,...,t_T.
#
# Use:
#     [lambda,V,Y,mu,I]=SFPCA(X,I,c);
#
# (C) Pedro Delicado, R-version: June 2015
#
sfpca.biv <- function(X,I1=seq(1,T1),I2=seq(1,T2),T1=NULL, T2=NULL,nc=4, wt = rep(1/ncol(X), ncol(X)), change.signs=rep(1,nc)){
  T1T2 <- dim(X)[1]
  n <- dim(X)[2]
  T1<-length(I1)
  T2<-length(I2)
  #
  # Centering data
  if (any(wt < 0) || (s <- sum(wt)) == 0) 
    stop("weights must be non-negative and not all zero")
  wt <- wt/s
  center <- colSums(wt %*% t(X))
  mu <- array(center,dim=c(T1T2,1))
  Xc <- X - mu %*% array(1,dim=c(1,n))
  # Computing matrix M
  M <- array(0,dim=c(n,n))
  part.int <- numeric(T1)
  h1 <- diff(I1)
  h2 <- diff(I2)
  for (i in seq(1,n)){ 
    for (j in seq(1,i)){
      for (k in 1:T1){
        XcXc.k <- Xc[(k-1)*T2+(1:T2),i]*Xc[(k-1)*T2+(1:T2),j]
        part.int[k] <- sum( .5*( XcXc.k[2:T2] + XcXc.k[1:(T2-1)] ) * h2 )
      }
      M[i,j] <- sum( .5*( part.int[2:T1] + part.int[1:(T1-1)] ) * h1 )
      M[j,i]=M[i,j]
    }
  }
  #
  # Computing of the eigensytem of M
  eigM <- eigen(M, symmetric=TRUE)
  lambda <- eigM$values
  w <- eigM$vectors[,1:nc]
  #
  # Computing matrix Y
  auxM <- array(0,dim=c(nc,nc))
  diag(auxM) <- lambda[1:nc]^(.5)
  Y <- w %*% auxM
  # 
  # Computing eigenfunctions #### August 2, 2013: I've added "%*% diag(lambda[1:nc]^(-1))" after reading again Kneip & Utikal (2001)
  V <- as.matrix(Xc) %*% Y %*% diag(lambda[1:nc]^(-1))
  signs <- diag( sign(apply(V,2,sum)) ) * change.signs
  #
  # Reconstructing X with nc principal components
  recX <- mu %*% array(1,dim=c(1,n)) + Xc %*% w %*% t(w) 
  return(list(w=w%*%signs,lambda=lambda,pctvar=100*lambda/sum(lambda),V=V%*%signs,Y=Y%*%signs,mu=mu,recX=recX,I=I,X=X))
}





# plot.biv.sfpca 
#  Graphics for Sampling Functional Principal Component Analysis on bivariate functions (with 2 arguments). 
#  Only 3 PC.
#
# This program provided a graphical output to SFPCA analysis. It is asumed that 
# program SFPC was runned.
#
# Input:
#   sfpcaout  A list obtained from sfpc function, with the following elements:
#                 w  nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#         nc  (Optional) Number of components to be ploted.
#             Default: nc=dim(sfpcaout$V)[2];
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#      color  (Optional) Color to be used to print the names of the n observed curves.
#             Default: all in black
#
plot.biv.sfpca <- function(sfpcaout,arg.1,arg.2,label=seq(1,length(sfpcaout$lambda)),nc=c(3,4),color=1,equispaced=TRUE,...){
  lambda <- sfpcaout$lambda
  pctvar <- sfpcaout$pctvar
  V <- sfpcaout$V
  Y <- sfpcaout$Y
  mu <- sfpcaout$mu
  I <- sfpcaout$I
  
  if (length(I)!=length(arg.1)*length(arg.2)) stop("length(I)!=length(arg.1)*length(argt.2)")
  
  n <- length(lambda)
  T <- dim(V)[1]
  
  par(mfrow=c(3,nc))
  # par(mfrow=c(4,2))
  
  # eigenvalues
  plot(pctvar,type='l',xlab="PC",ylab="% of variance")
  text(seq(1,nc)+.75,pctvar[1:nc],as.character(round(pctvar[1:nc],digits=2)))
  title("% of var. explained by each PC")
  
  # 2nd vs 1st principal coordinates
  plot(Y[,1],Y[,2], pch='.',xlab='1st principal function', ylab='2nd principal function')
  title(main= '2nd vs 1st PCs')
  text(Y[,1],Y[,2],label, col=color)
  
  # 3rd vs 1st principal coordinates
  plot(Y[,1],Y[,3], pch='.',xlab='1st principal function', ylab='3rd principal function')
  title(main= '3rd vs 1st PCs')
  text(Y[,1],Y[,3],label, col=color)
  
  if (nc==4){
    # 4th vs 1st principal coordinates
    plot(Y[,1],Y[,4], pch='.',xlab='1st principal function', ylab='4th principal function')
    title(main= '4th vs 1st PCs')
    text(Y[,1],Y[,4],label, col=color)
  }
  
  
  # principal curves
  for (j in seq(1,nc)){
    image(arg.1,arg.2,matrix(V[,j],nrow=length(arg.1),ncol=length(arg.2),byrow=T), 
          xlab = deparse(substitute(arg.1)), ylab=deparse(substitute(arg.2)),
          main=paste("PC ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""))  
    #contour(arg.1,arg.2,matrix(V[,j],nrow=length(arg.1),ncol=length(arg.2),byrow=T),
    #        add=TRUE,levels=c(0),lwd=2)
  }
  
  # principal curves
  for (j in seq(1,nc)){
    persp(arg.1,arg.2,matrix(V[,j],nrow=length(arg.1),ncol=length(arg.2),byrow=T), 
          main=paste("PC ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""),
          xlab = deparse(substitute(arg.1)), ylab=deparse(substitute(arg.2)), zlab=paste("PC ",j,sep=""),
          theta = 320, phi = 35, expand = 1, col = "lightblue", d=1.5,
          ltheta = 120, shade = 0.15, ticktype = "detailed")  
  }
}


# plot.biv.sfpca.image 
#  Graphics for Sampling Functional Principal Component Analysis on bivariate functions (with 2 arguments). 
#  Only 3 PC. Only image plots
#
# This program provided a graphical output to SFPCA analysis. It is asumed that 
# program SFPC was runned.
#
# Input:
#   sfpcaout  A list obtained from sfpc function, with the following elements:
#                 w  nc principal components of Var(t(X)*X) defined from data curves X  
#             lambda  Set of the n nonzero eigenvalues of the sampling covariance operator Sigma
#                     defined from data curves X  
#             pctvar  Percentage of variance explined by each component
#                 V  (T,c) matrix with the eigenfunctions of Sigma evaluated at I.
#                 Y  (T,c) matrix with the value of the first c sampling functional 
#                    principal Components.
#                mu  aritmetic mean of the n functions in X
#              recX  Reconstruction of matrix X from the nc principal functions
#                 I  The set of index points: t_1,...,t_T.
#         nc  (Optional) Number of components to be ploted.
#             Default: nc=dim(sfpcaout$V)[2];
#      label  (Optional) Label names for the n observed curves.
#             Default: num2str([1:n])
#      color  (Optional) Color to be used to print the names of the n observed curves.
#             Default: all in black
#
plot.biv.sfpca.image <- function(sfpcaout,arg.1,arg.2,label=seq(1,length(sfpcaout$lambda)),nc=c(3,4),color=1,equispaced=TRUE,...){
  lambda <- sfpcaout$lambda
  pctvar <- sfpcaout$pctvar
  V <- sfpcaout$V
  Y <- sfpcaout$Y
  mu <- sfpcaout$mu
  I <- sfpcaout$I
  
  if (length(I)!=length(arg.1)*length(arg.2)) stop("length(I)!=length(arg.1)*length(argt.2)")
  
  n <- length(lambda)
  T <- dim(V)[1]
  
  par(mfrow=c(nc,2))
  # par(mfrow=c(4,2))
  
  # eigenvalues
  # plot(pctvar,type='l',xlab="Ppal. Funct.",ylab="% of var.")
  plot(pctvar[1:max(nc,min(20,length(pctvar)))],type='l',xlab="Eigenfunction",ylab="FVE in %")
  # title("% of var. explained by each Ppal. Funct.")
  title("FVE by each eigenfunction")
  text(seq(1,nc)+.75,pctvar[1:nc],as.character(round(pctvar[1:nc],digits=2)))
  
  # 2nd vs 1st principal coordinates
  # plot(Y[,1],Y[,2], pch='.',xlab='1st principal function', ylab='2nd principal function')
  plot(Y[,1],Y[,2], pch='.',xlab='1st eigenfunction', ylab='2nd eigenfunction')
  # title(main= 'Scores at 2nd vs 1st Ppal. Functs.')
  title(main= 'Scores at 2nd vs 1st eigenfunctions')
  text(Y[,1],Y[,2],label, col=color)
  
  # 3rd vs 1st principal coordinates
  #plot(Y[,1],Y[,3], pch='.',xlab='1st principal function', ylab='3rd principal function')
  plot(Y[,1],Y[,3], pch='.',xlab='1st eigenfunction', ylab='3rd eigenfunction')
  #title(main= 'Scores at 3rd vs 1st Ppal. Functs.')
  title(main= 'Scores at 3rd vs 1st eigenfunctions')
  text(Y[,1],Y[,3],label, col=color)
  
  if (nc==4){
    # 4th vs 1st principal coordinates
    # plot(Y[,1],Y[,4], pch='.',xlab='1st principal function', ylab='4th principal function')
    plot(Y[,1],Y[,4], pch='.',xlab='1st eigenfunction', ylab='4th eigenfunction')
    # title(main= 'Scores at 4th vs 1st Ppal. Functs.')
    title(main= 'Scores at 4th vs 1st eigenfunctions')
    text(Y[,1],Y[,4],label, col=color)
  }
  
  
  # principal curves
  for (j in seq(1,nc)){
    image(arg.1,arg.2,matrix(V[,j],nrow=length(arg.1),ncol=length(arg.2),byrow=T), 
          xlab = deparse(substitute(arg.1)), ylab=deparse(substitute(arg.2)),
          # main=paste("Ppal. Funct. ",j," (",round(pctvar[j],dig=2),"% of var.)",sep=""))  
          main=paste("Ppal. Funct. ",j," (FVE: ",round(pctvar[j],dig=2),"%)",sep=""))  
    
    #    contour(arg.1,arg.2,matrix(V[,j],nrow=length(arg.1),ncol=length(arg.2),byrow=T),
    #            add=TRUE,levels=c(0),lwd=2)
  }
}
